let abs = (x) => Math.abs(x),
acos = (x) => Math.acos(x),	
acosh = (x) => Math.acosh(x) ,
asin  = (x) => Math.asin(x)	,
asinh  = (x) => Math.asinh(x),	
atan  = (x) => Math.atan(x)	,
atan2  = (y,x) => Math.atan2(y, x)	,
atanh  = (x) => Math.atanh(x),
cbrt  = (x) => Math.cbrt(x)	,
ceil  = (x) => Math.ceil(x)	,
clz32 = (x) => Math.clz32(x),	
cos  = (x) => Math.cos(x)	,
cosh  = (x) => Math.cosh(x),
exp  = (x) => Math.exp(x)	,
expm1  = (x) => Math.expm1(x),
floor  = (x) => Math.floor(x)	,
fround  = (x) => Math.fround(x),	
log  = (x) => Math.log(x)	  , ln = (x) => Math.log(x),
log10  = (x) => Math. log10(x)	,
log1p  = (x) => Math. log1p(x)	,
log2  = (x) => Math. log2(x)	,
max = (...args)=> Math.max.apply(null, args),
min = (...args)=> Math.min.apply(null, args),
pow  = (x,y) => Math. pow(x, y),
random  = () => Math. random()	,
round  = (x) => Math. round(x)	,
sign = (x) => Math. sign(x)	, sgn = (x) => Math.sign(x),
sin  = (x) => Math. sin(x)	,
sinh  = (x) => Math. sinh(x),	
sqrt = (x) => Math. sqrt(x)	,
tan = (x) => Math. tan(x)	,
tanh = (x) => Math. tanh(x),	
trunc = (x) => Math. trunc(x)

const E	= Math.E
const LN2	= Math.LN2
const LN10 = Math.LN10
const LOG2E	= Math.LOG2E
const LOG10E = Math.LOG10E
const PI= Math.PI
const SQRT1_2	= Math.SQRT1_2
const SQRT2= Math.SQRT2





